package com.example.personalweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    DatabaseAid mDatabaseAid;
    private EditText editText;

    //onCreate for main page and buttons
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        editText = findViewById(R.id.editText);
        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnViewData = findViewById(R.id.btnView);
        findViewById(R.id.btnSMS);
        mDatabaseAid = new DatabaseAid(this);

        //Add data button
        btnAdd.setOnClickListener(v -> {
            String newEntry = editText.getText().toString();
            if (editText.length() != 0) {
                AddData(newEntry);
                editText.setText("");
            } else {
                toastMessage("Text Field requires Input!");
            }

        });

        //View data
        btnViewData.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ListData.class);
            startActivity(intent);
        });
    }

    //Insert data and send toast message
    public void AddData(String newEntry) {
        boolean insertData = mDatabaseAid.addData(newEntry);

        if (insertData) {
            toastMessage("Data Successfully Inserted!");
        } else {
            toastMessage("Please Try Again");
        }
    }
    void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}