package com.example.personalweighttracker;


import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class ListData extends AppCompatActivity {

    private static final String TAG = "ListDataActivity";

    DatabaseAid mDatabaseAid;

    private ListView mListView;

    //onCreate method for population of user data
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_layout);
        mListView = findViewById(R.id.listView);
        mDatabaseAid = new DatabaseAid(this);

        populateListView();
    }

    //Create list
    private void populateListView() {
        Log.d(TAG, "populateListView: Displaying data in ListView.");

        Cursor data = mDatabaseAid.getData();
        ArrayList<String> listData = new ArrayList<>();
        while(data.moveToNext()){

            listData.add(data.getString(1));
        }

        //Create list adapter
        ListAdapter adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listData);
        mListView.setAdapter(adapter);

        //Set an onItemClickListener
        mListView.setOnItemClickListener((adapterView, view, i, l) -> {
            String name = adapterView.getItemAtPosition(i).toString();
            Log.d(TAG, "onItemClick: You clicked " + name);

            Cursor data1 = mDatabaseAid.getItemID(name); //get the id associated with that name
            int itemID = -1;
            while(data1.moveToNext()){
                itemID = data1.getInt(0);
            }
            if(itemID > -1){
                Log.d(TAG, "onItemClick: The ID is: " + itemID);
                Intent editScreenIntent = new Intent(ListData.this, EditData.class);
                editScreenIntent.putExtra("id",itemID);
                editScreenIntent.putExtra("name",name);
                startActivity(editScreenIntent);
            }
            else{
                toastMessage();
            }
        });
    }
    //Custom toast message
    private void toastMessage(){
        Toast.makeText(this, "No ID associated with given name", Toast.LENGTH_SHORT).show();
    }
}