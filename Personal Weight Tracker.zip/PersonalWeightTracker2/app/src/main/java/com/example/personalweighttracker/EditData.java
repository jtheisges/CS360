package com.example.personalweighttracker;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class EditData extends AppCompatActivity {

    private EditText editable_item;

    DatabaseAid mDatabaseAid;

    private String selectedName;
    private int selectedID;

    //onCreate for buttons and list view
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.edit_data_layout);
        //Declare variable and DB
        Button btnSave = findViewById(R.id.btnSave);
        Button btnDelete = findViewById(R.id.btnDelete);
        editable_item = findViewById(R.id.editable_item);
        Button btnBack = findViewById(R.id.btnBack);
        mDatabaseAid = new DatabaseAid(this);

        Intent receivedIntent = getIntent();
        selectedID = receivedIntent.getIntExtra("id",-1); //NOTE: -1 is just the default value
        selectedName = receivedIntent.getStringExtra("name");
        editable_item.setText(selectedName);

        //Save button
        btnSave.setOnClickListener(view -> {
            String item = editable_item.getText().toString();
            if(!item.equals("")){
                mDatabaseAid.updateName(item,selectedID,selectedName);
            }else{
                toastMessage("Name field required");
            }
        });

        //Delete button
        btnDelete.setOnClickListener(view -> {
            mDatabaseAid.deleteName(selectedID,selectedName);
            editable_item.setText("");
            toastMessage("Removed from database!");
        });

        //Back button
        btnBack.setOnClickListener(view -> {
            Intent intent = new Intent(EditData.this, MainActivity.class);
            startActivity(intent);
        });
    }

    //Custom toast message
    private void toastMessage(String message){
        Toast.makeText(this,message, Toast.LENGTH_SHORT).show();
    }
}