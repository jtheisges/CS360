package com.example.personalweighttracker;


import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;


//Public class for log in and registration
public class Login extends AppCompatActivity {

    //Declare variables
    EditText username, password;
    Button login, register;
    Helper DB;

    //onCreate for buttons and toast messages
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_activity);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        login = findViewById(R.id.login);
        register = findViewById(R.id.register);
        DB = new Helper(this);

        //log in button set up
        //oncClick button use detection
        login.setOnClickListener(view -> {

            String user = username.getText().toString();
            String pass = password.getText().toString();

            if (user.equals("") || pass.equals(""))
                Toast.makeText(Login.this, "Please Complete all Fields!", Toast.LENGTH_SHORT).show();
            else {
                Boolean checkUserPass = DB.checkUsernamePassword(user, pass);
                if (checkUserPass) {
                    Toast.makeText(Login.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(Login.this, MainActivity.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(Login.this, "Login Failed, please try again.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        //register button set up
        //onCLick for button use detection and password/username comparison
        register.setOnClickListener(view -> {
            String user = username.getText().toString();
            String pass = password.getText().toString();

            if (user.equals("") || pass.equals(""))
                Toast.makeText(Login.this, "Please Complete all Fields!", Toast.LENGTH_SHORT).show();
            else {
                if (pass.equals(pass)) {
                    boolean checkuser = DB.checkUsername(user);
                    if (!checkuser) {
                        boolean insert = DB.insertData(user, pass);
                        if (insert) {
                            Toast.makeText(Login.this, "Registration Successful! Please Log In!", Toast.LENGTH_SHORT).show();
                        }
                        else {
                            Toast.makeText(Login.this, "Registration Failed!", Toast.LENGTH_SHORT).show();
                        }
                    }
                    else {
                        Toast.makeText(Login.this, "User Already Registered, Please Login.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
